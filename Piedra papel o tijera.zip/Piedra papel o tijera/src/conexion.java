
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class conexion {

    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/test";
        String username = "root";
        String password = "";
        Connection con = null;
        Statement stmnt = null;
  
        try {
            
            con = DriverManager.getConnection(url, username, password);
            System.out.println("Conectado");
        } catch (SQLException ex){
          //  ex.printStackTrace();
            System.out.println("connection Error!!");
        }
        
        }
    private Connection conn;
    public Connection getconnection (){
        return conn;
    }
    public void desconectar(){
        conn = null;
    }

    com.sun.jdi.connect.spi.Connection conectar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  } 

